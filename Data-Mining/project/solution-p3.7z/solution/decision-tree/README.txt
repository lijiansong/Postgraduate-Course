#Note
This archive is the implement of decision tree. It uses correlation coefficient to reduce the data, information entropy to discretize continous attribute, and information gain to decide which attribute as the split attribute. Its time consumption mainly focuses on data discretization and recursively build the decision tree.

#Build
$ cd folder-name
$ make clean
$ make
$ ./decision-tree training_dataset test_dataset
