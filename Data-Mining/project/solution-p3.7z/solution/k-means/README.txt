#Note
This archive is the implement of k-means. It randomly chooses k(it is 5 here) records as the seed, and calculatea the center, distributes the nearest records to the new cluster until there is no new records distribution. The "result" folder is the prediction result of after and before data reduction.
Before reduction, confusion matrix:
T/P  0      1      2      3      4      
0    57584  230    2737   0      42     
1    1153   2666   347    0      0      
2    6041   65     223747 0      0      
3    203    0      19     0      6      
4    15628  18     541    0      2      

After reduction, confution matrix:
T/P  0      1      2      3      4      
0    74775  3596   905    0      46     
1    143    223136 19     0      0      
2    218    120    2039   0      0      
3    31     4      0      0      4      
4    5442   535    16     0      0      

#Build
$ cd folder-name
$ make clean
$ make
$ ./k-means
