#Note
This archive is about data pre-processing, using correlation coefficient to reduce the data.

#Build
$ cd folder-name
$ make clean
$ make
$ ./pre-process data_file_name
