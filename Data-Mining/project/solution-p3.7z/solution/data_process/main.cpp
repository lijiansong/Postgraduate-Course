#include "pre_process.h"

int main(int argc, char *argv[])
{
	FILE *pInFile, *pOutFile;
	
	if (argc != 2)
	{
		cout << "params error !" << endl;
		return -1;
	}
	char *inputFileName;
	inputFileName = new char[30];
	strcpy (inputFileName, argv[1]);

	//kddcup.data_10_percent.txt
	if ((pInFile = fopen (inputFileName, "r")) == NULL)	
	{
		cout << "fail to open training dataset file!" << endl;
		return -1;
	}
	clock_t start,finish;
	//double duration;
	cout << "start reading records from " << argv[1] << "..." << endl;
	start=clock();
	feature_list data=getData(pInFile);
	finish=clock();
	cout<<"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"<<endl;
	cout<<((double)(finish-start))/CLOCKS_PER_SEC<<endl;

	const char *outfname = "_preprocessing";
	char *outputFileName;
	outputFileName = strcat (inputFileName, outfname);
	if ((pOutFile = fopen (outputFileName, "w")) == NULL)
	{
		fclose (pInFile);
		cout << "fail to create _preprocessing file!" << endl;
		return -1;
	}

	cout << "Start writing records into " << outputFileName<< " ..." << endl;
	start=clock();
	writeToFile(pOutFile,data);
	finish=clock();
	cout<<"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"<<endl;
	cout<<((double)(finish-start))/CLOCKS_PER_SEC<<endl;

	//fclose(pInFile);
	//fclose(pOutFile);
	return 0;
}
