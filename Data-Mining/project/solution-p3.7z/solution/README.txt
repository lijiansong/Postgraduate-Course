#Note
This archieve is the source code of three methods: decision tree, k-means and knn.
Each dir contains the prediction result and the build steps, you can follow the README file to run the code.