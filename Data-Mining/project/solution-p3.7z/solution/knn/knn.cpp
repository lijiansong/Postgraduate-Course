#include <ctime>
#include <map>
#include <string>
#include <sstream>
#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <cstring>

using namespace std;

const string TRAIN_FILE = "kddcup.data_10_percent.txt";
const string TEST_FILE = "testdata_unlabeled_50000.txt";
const string GUESS_LABEL_FEATURE_DESCREASED_FILE = "Guessed_label.feature_descreased";
const string GUESS_LABEL_FEATURE_UNDESCREASED_FILE = "Guessed_label.feature_undescreased";
const bool FEATURE_DECREASED = true;

double DURATION_MAX = 58329;            // Interval length (from 0 to variable).
double WRONG_FRAGMENT_MAX = 3;          // Listed in order they appear in data set.
double URGENT_MAX = 14;
double HOT_MAX = 101;
double NUM_FAILED_LOGINS_MAX = 5;
double NUM_COMPROMISED_MAX = 9;
double SU_ATTEMPTED_MAX = 2;
double NUM_ROOT_MAX = 7468;
double NUM_FILE_CREATIONS_MAX = 100;
double NUM_SHELLS_MAX = 5;
double NUM_ACCESS_FILES_MAX = 9;
double COUNT_MAX = 511;
double SRV_COUNT_MAX = 511;
double DST_HOST_COUNT_MAX = 255;
double DST_HOST_SRV_COUNT_MAX = 255;

double AMOUNT_OF_FLAGS = 11;            // Amount of different strings of that field.
double AMOUNT_OF_LABELS = 5;
double AMOUNT_OF_PROTOCOLS = 3;
double AMOUNT_OF_SERVICES = 70;

static map<string, double> flagMap;     // Used to map strings to numbers.
static map<string, double> labelMap;
static map<string, double> protocolMap;
static map<string, double> serviceMap;

struct features {
    double duration;
    double protocol_type;
    double service;
    double flag;
    double src_bytes;
    double dst_bytes;
    double land;
    double wrong_fragment;
    double urgent;
    double hot;
    double num_failed_logins;
    double logged_in;
    double num_compromised;
    double root_shell;
    double su_attempted;
    double num_root;
    double num_file_creations;
    double num_shells;
    double num_access_files;
    double num_outbound_cmds;
    double is_host_login;
    double is_guest_login;
    double count;
    double srv_count;
    double serror_rate;
    double srv_serror_rate;
    double rerror_rate;
    double srv_rerror_rate;
    double same_srv_rate;
    double diff_srv_rate;
    double srv_diff_host_rate;
    double dst_host_count;
    double dst_host_srv_count;
    double dst_host_same_srv_rate;
    double dst_host_diff_srv_rate;
    double dst_host_same_src_port_rate;
    double dst_host_srv_diff_host_rate;
    double dst_host_serror_rate;
    double dst_host_srv_serror_rate;
    double dst_host_rerror_rate;
    double dst_host_srv_rerror_rate;
    double label; // Labeled data, does NOT have a value for unlabeled data set.
};

struct colon_separated_only: ctype<char>
{
    colon_separated_only(): ctype<char>(get_table()) {}

    static ctype_base::mask const* get_table()
    {
        typedef ctype<char> cctype;
        static const cctype::mask *const_rc= cctype::classic_table();

        static cctype::mask rc[cctype::table_size];
        memcpy(rc, const_rc, cctype::table_size * sizeof(cctype::mask));

        rc[','] = ctype_base::space;
        return &rc[0];
    }
};

int preProcessFlag(string flag);
int preProcessLabel(string label);
int preProcessProtocol(string protocol);
int preProcessService(string service);
void get_data(const string &train_file, const string &test_file, 
	vector<features> &train_samples, vector<features> &test_samples);
void knn(vector<features> &train_samples, vector<features> &test_samples, int k);
void printAllData(vector<features> &data);
double dist(features a, features b);


int main() {
	vector<features> train_samples;
	vector<features> test_samples;
    
	get_data(TRAIN_FILE, TEST_FILE, train_samples, test_samples);
	for (int k = 1; k < 2; ++k){
        time_t start_time, end_time;
        start_time = clock();
		knn(train_samples, test_samples, k);
        end_time = clock();
        cout << "Time used for k = " << k << " is " 
            << (double)(end_time-start_time)/CLOCKS_PER_SEC<< "s." << endl;
	}
}

int preProcessFlag(string flag)
{
    if(flagMap.size() == 0) // If the map has not been created.
    {
        flagMap["SF"] = 0;
        flagMap["S2"] = 1;
        flagMap["S1"] = 2;
        flagMap["S3"] = 3;
        flagMap["OTH"] = 4;
        flagMap["REJ"] = 5;
        flagMap["RSTO"] = 6;
        flagMap["S0"] = 7;
        flagMap["RSTR"] = 8;
        flagMap["RSTOS0"] = 9;
        flagMap["SH"] = 10;
    }
    return flagMap[flag];
}

int preProcessLabel(string label)
{
    if(labelMap.size() == 0) // If the map has not been created.
    {
        labelMap["normal."] = 0;
        labelMap["back."] = 2;
        labelMap["buffer_overflow."] = 3;
        labelMap["ftp_write."] = 4;
        labelMap["guess_passwd."] = 4;
        labelMap["imap."] = 4;
        labelMap["ipsweep."] = 1;
        labelMap["land."] = 2;
        labelMap["loadmodule."] = 3;
        labelMap["multihop."] = 4;
        labelMap["neptune."] = 2;
        labelMap["nmap."] = 1;
        labelMap["perl."] = 3;
        labelMap["phf."] = 4;
        labelMap["pod."] = 2;
        labelMap["portsweep."] = 1;
        labelMap["rootkit."] = 3;
        labelMap["satan."] = 1;
        labelMap["smurf."] = 2;
        labelMap["spy."] = 4;
        labelMap["teardrop."] = 2;
        labelMap["warezclient."] = 4;
        labelMap["warezmaster."] = 4;
        labelMap["apache2."] = 2;
        labelMap["ps."] = 3;
        labelMap["mscan."] = 1;
        labelMap["sendmail."] = 4;
        labelMap["xsnoop."] = 4;
        labelMap["httptunnel."] = 3;
        labelMap["xlock."] = 4;
        labelMap["snmpguess."] = 4;
        labelMap["snmpgetattack."] = 4;
        labelMap["xterm."] = 3;
        labelMap["worm."] = 4;
        labelMap["sqlattack."] = 3;
        labelMap["processtable."] = 2;
        labelMap["saint."] = 1;
        labelMap["udpstorm."] = 2;
        labelMap["mailbomb."] = 2;
        labelMap["named."] = 4;
    }
    return labelMap[label];
}

int preProcessProtocol(string protocol)
{
    if(protocolMap.size() == 0) // If the map has not been created.
    {
        protocolMap["tcp"] = 0;
        protocolMap["udp"] = 1;
        protocolMap["icmp"] = 2;
    }
    return protocolMap[protocol];
}

int preProcessService(string service)
{
    if(serviceMap.size() == 0) // If the map has not been created.
    {
        serviceMap["http"] = 0;
        serviceMap["smtp"] = 1;
        serviceMap["domain_u"] = 2;
        serviceMap["auth"] = 3;
        serviceMap["finger"] = 4;
        serviceMap["telnet"] = 5;
        serviceMap["eco_i"] = 6;
        serviceMap["ftp"] = 7;
        serviceMap["ntp_u"] = 8;
        serviceMap["ecr_i"] = 9;
        serviceMap["other"] = 10;
        serviceMap["urp_i"] = 11;
        serviceMap["private"] = 12;
        serviceMap["pop_3"] = 13;
        serviceMap["ftp_data"] = 14;
        serviceMap["netstat"] = 15;
        serviceMap["daytime"] = 16;
        serviceMap["ssh"] = 17;
        serviceMap["echo"] = 18;
        serviceMap["time"] = 19;
        serviceMap["name"] = 20;
        serviceMap["whois"] = 21;
        serviceMap["domain"] = 22;
        serviceMap["mtp"] = 23;
        serviceMap["gopher"] = 24;
        serviceMap["remote_job"] = 25;
        serviceMap["rje"] = 26;
        serviceMap["ctf"] = 27;
        serviceMap["supdup"] = 28;
        serviceMap["link"] = 29;
        serviceMap["systat"] = 30;
        serviceMap["discard"] = 31;
        serviceMap["X11"] = 32;
        serviceMap["shell"] = 33;
        serviceMap["login"] = 34;
        serviceMap["imap4"] = 35;
        serviceMap["nntp"] = 36;
        serviceMap["uucp"] = 37;
        serviceMap["pm_dump"] = 38;
        serviceMap["IRC"] = 39;
        serviceMap["Z39_50"] = 40;
        serviceMap["netbios_dgm"] = 41;
        serviceMap["ldap"] = 42;
        serviceMap["sunrpc"] = 43;
        serviceMap["courier"] = 44;
        serviceMap["exec"] = 45;
        serviceMap["bgp"] = 46;
        serviceMap["csnet_ns"] = 47;
        serviceMap["http_443"] = 48;
        serviceMap["klogin"] = 49;
        serviceMap["printer"] = 50;
        serviceMap["netbios_ssn"] = 51;
        serviceMap["pop_2"] = 52;
        serviceMap["nnsp"] = 53;
        serviceMap["efs"] = 54;
        serviceMap["hostnames"] = 55;
        serviceMap["uucp_path"] = 56;
        serviceMap["sql_net"] = 57;
        serviceMap["vmnet"] = 58;
        serviceMap["iso_tsap"] = 59;
        serviceMap["netbios_ns"] = 60;
        serviceMap["kshell"] = 61;
        serviceMap["urh_i"] = 62;
        serviceMap["http_2784"] = 63;
        serviceMap["harvest"] = 64;
        serviceMap["aol"] = 65;
        serviceMap["tftp_u"] = 66;
        serviceMap["http_8001"] = 67;
        serviceMap["tim_i"] = 68;
        serviceMap["red_i"] = 69;
    }
    return serviceMap[service];
}

void get_data(const string &train_file, const string &test_file, 
	vector<features> &train_samples, vector<features> &test_samples) {
	ifstream fin;
	fin.open(train_file.c_str(), ios::in);
	features temp;
	string line;
	string protocol_type, service, flag, label;
	
	cout << "Start reading data..." << endl;
	while (fin.good() == true) {
		getline(fin, line);
		stringstream ss(line);
		ss.imbue(std::locale(std::locale(), new colon_separated_only()));
		while ( ss >> temp.duration >> protocol_type >> service >> flag >> temp.src_bytes >>
                temp.dst_bytes >> temp.land >> temp.wrong_fragment >> temp.urgent >> temp.hot >>
                temp.num_failed_logins >> temp.logged_in >> temp.num_compromised >> temp.root_shell >> temp.su_attempted >>
                temp.num_root >> temp.num_file_creations >> temp.num_shells >> temp.num_access_files >> temp.num_outbound_cmds >>
                temp.is_host_login >> temp.is_guest_login >> temp.count >> temp.srv_count >> temp.serror_rate >>
                temp.srv_serror_rate >> temp.rerror_rate >> temp.srv_rerror_rate >> temp.same_srv_rate >> temp.diff_srv_rate >>
                temp.srv_diff_host_rate >> temp.dst_host_count >> temp.dst_host_srv_count >> temp.dst_host_same_srv_rate >> 
                temp.dst_host_diff_srv_rate >> temp.dst_host_same_src_port_rate >> temp.dst_host_srv_diff_host_rate >> 
                temp.dst_host_serror_rate >> temp.dst_host_srv_serror_rate >> temp.dst_host_rerror_rate >>
                temp.dst_host_srv_rerror_rate >> label)
        {
            // Preprocessing data (linearly scaled).
            temp.duration = temp.duration / DURATION_MAX;
            temp.wrong_fragment = temp.wrong_fragment / WRONG_FRAGMENT_MAX;
            temp.urgent = temp.urgent / URGENT_MAX;
            temp.hot = temp.hot / HOT_MAX;
            temp.num_failed_logins = temp.num_failed_logins / NUM_FAILED_LOGINS_MAX;
            temp.num_compromised = temp.num_compromised / NUM_COMPROMISED_MAX;
            temp.num_root = temp.num_root / NUM_ROOT_MAX;
            temp.num_file_creations = temp.num_file_creations / NUM_FILE_CREATIONS_MAX;
            temp.num_shells = temp.num_shells / NUM_SHELLS_MAX;
            temp.num_access_files = temp.num_access_files / NUM_ACCESS_FILES_MAX;
            temp.count = temp.count / COUNT_MAX;
            temp.srv_count = temp.srv_count / SRV_COUNT_MAX;
            temp.dst_host_count = temp.dst_host_count / DST_HOST_COUNT_MAX;
            temp.dst_host_srv_count = temp.dst_host_srv_count / DST_HOST_SRV_COUNT_MAX;

            // Preprocessing data (logarithmically scalled).
            if(temp.src_bytes != 0)
            {
                temp.src_bytes = log10(temp.src_bytes);
            }
            if(temp.dst_bytes != 0)
            {
                temp.dst_bytes = log10(temp.dst_bytes);
            }
            temp.label = preProcessLabel(label);// / (AMOUNT_OF_LABELS - 1));
            temp.protocol_type = (preProcessProtocol(protocol_type) / (AMOUNT_OF_PROTOCOLS - 1));
            temp.service = (preProcessService(service) / (AMOUNT_OF_SERVICES - 1));
            temp.flag = (preProcessFlag(flag) / (AMOUNT_OF_FLAGS - 1));

            train_samples.push_back(temp);  // Adds the entry to the vector.
        }
	}
	fin.close();

	fin.open(test_file.c_str(), ios::in);
	
	while (fin.good() == true) {
		getline(fin, line);
		stringstream ss(line);
		ss.imbue(std::locale(std::locale(), new colon_separated_only()));
		while ( ss >> temp.duration >> protocol_type >> service >> flag >> temp.src_bytes >>
                temp.dst_bytes >> temp.land >> temp.wrong_fragment >> temp.urgent >> temp.hot >>
                temp.num_failed_logins >> temp.logged_in >> temp.num_compromised >> temp.root_shell >> temp.su_attempted >>
                temp.num_root >> temp.num_file_creations >> temp.num_shells >> temp.num_access_files >> temp.num_outbound_cmds >>
                temp.is_host_login >> temp.is_guest_login >> temp.count >> temp.srv_count >> temp.serror_rate >>
                temp.srv_serror_rate >> temp.rerror_rate >> temp.srv_rerror_rate >> temp.same_srv_rate >> temp.diff_srv_rate >>
                temp.srv_diff_host_rate >> temp.dst_host_count >> temp.dst_host_srv_count >> temp.dst_host_same_srv_rate >> 
                temp.dst_host_diff_srv_rate >> temp.dst_host_same_src_port_rate >> temp.dst_host_srv_diff_host_rate >> 
                temp.dst_host_serror_rate >> temp.dst_host_srv_serror_rate >> temp.dst_host_rerror_rate >>
                temp.dst_host_srv_rerror_rate)
        {        	
            temp.duration = temp.duration / DURATION_MAX;
            temp.wrong_fragment = temp.wrong_fragment / WRONG_FRAGMENT_MAX;
            temp.urgent = temp.urgent / URGENT_MAX;
            temp.hot = temp.hot / HOT_MAX;
            temp.num_failed_logins = temp.num_failed_logins / NUM_FAILED_LOGINS_MAX;
            temp.num_compromised = temp.num_compromised / NUM_COMPROMISED_MAX;
            temp.su_attempted = temp.su_attempted / SU_ATTEMPTED_MAX;
            temp.num_root = temp.num_root / NUM_ROOT_MAX;
            temp.num_file_creations = temp.num_file_creations / NUM_FILE_CREATIONS_MAX;
            temp.num_shells = temp.num_shells / NUM_SHELLS_MAX;
            temp.num_access_files = temp.num_access_files / NUM_ACCESS_FILES_MAX;
            temp.count = temp.count / COUNT_MAX;
            temp.srv_count = temp.srv_count / SRV_COUNT_MAX;
            temp.dst_host_count = temp.dst_host_count / DST_HOST_COUNT_MAX;
            temp.dst_host_srv_count = temp.dst_host_srv_count / DST_HOST_SRV_COUNT_MAX;

            if(temp.src_bytes != 0)
            {
                temp.src_bytes = log10(temp.src_bytes);
            }
            if(temp.dst_bytes != 0)
            {
                temp.dst_bytes = log10(temp.dst_bytes);
            }
            temp.protocol_type = (preProcessProtocol(protocol_type) / (AMOUNT_OF_PROTOCOLS - 1));
            temp.service = (preProcessService(service) / (AMOUNT_OF_SERVICES - 1));
            temp.flag = (preProcessFlag(flag) / (AMOUNT_OF_FLAGS - 1));

            test_samples.push_back(temp);  // Adds the entry to the vector.
        }
	}
	fin.close();
	cout << train_samples.size() << "  " << test_samples.size() << endl;
	cout << "Data reading end..." << endl;
}

void knn(vector<features> &train_samples, vector<features> &test_samples, int k) {
	cout << "Start knn algo when k is " << k << " ..." << endl;
	int test_size = test_samples.size();
	int train_size = train_samples.size();
	const int confusion_matrix_size = 5;
	double confusion_matrix[confusion_matrix_size][confusion_matrix_size];
	memset(confusion_matrix, 0, confusion_matrix_size*confusion_matrix_size*sizeof(double));

	double *distance = new double[train_size];
	double *label = new double[train_size];
	double *knnMinDistances = new double[k];
	double *knnMinLabels = new double[k];
	double *knnGuesses = new double[confusion_matrix_size];
	ofstream fout;
	if (FEATURE_DECREASED) {
		fout.open(GUESS_LABEL_FEATURE_DESCREASED_FILE.c_str(), ios::out);
	} else {
		fout.open(GUESS_LABEL_FEATURE_UNDESCREASED_FILE.c_str(), ios::out);
	}
	for (int i = 0; i < test_size; ++i) {
		for (int j = 0; j < train_size; ++j) {
			distance[j] = dist(train_samples[j], test_samples[i]);
			label[j] = train_samples[j].label;
		}
		for (int j = 0; j < k; ++j) {
			knnMinDistances[j] = distance[j];
			knnMinLabels[j] = label[j];
		}
		for (int j = k; j < train_size; ++j) {
			int temp_index = -1;
			double temp_distance = distance[j];
			for (int m = 0; m < k; ++m) {
				if (temp_distance < knnMinDistances[m]) {
					temp_distance = knnMinDistances[m];
					temp_index = m;
				}
			}
			if (temp_index != -1) {
				knnMinDistances[temp_index] = distance[j];
				knnMinLabels[temp_index] = label[j];
			}
		}
		memset(knnGuesses, 0, confusion_matrix_size*sizeof(double));
		for (int j = 0; j < k; ++j) {
			++knnGuesses[(int)knnMinLabels[j]];
		}
		int max_num = 0; double max_class = 0;
		for (int j = 0; j < confusion_matrix_size; ++j) {
			if (max_num < knnGuesses[j]) {
				max_num = knnGuesses[j];
				max_class = j;
			}
		}
		int guess_label = max_class;
		if (int(guess_label) == 0)
			fout << "normal" << endl;
		else if (int(guess_label) == 1)
			fout << "probe" << endl;
		else if (int(guess_label) == 2)
			fout << "dos" << endl;
		else if (int(guess_label) == 3)
			fout << "u2r" << endl;
		else if(int(guess_label) == 4)
			fout << "r2l" << endl;
	}
	fout.close();

	delete distance;
	delete label;
	delete knnMinDistances;
	delete knnMinLabels;
	delete knnGuesses;
}

void printAllData(vector<features> &data)
{
    for(size_t i = 0 ; i < data.size() ; ++i )
    {
        cout << data[i].duration << " " << data[i].protocol_type << " " << data[i].service << " " << data[i].flag << " " << data[i].src_bytes << endl;
        cout << data[i].dst_bytes << " " << data[i].land << " " << data[i].wrong_fragment << " " << data[i].urgent << " " << data[i].hot << endl;
        cout << data[i].num_failed_logins << " " << data[i].logged_in << " " << data[i].num_compromised << " " << data[i].root_shell << " " << data[i].su_attempted << endl;
        cout << data[i].num_root << " " << data[i].num_file_creations << " " << data[i].num_shells << " " << data[i].num_access_files << " " << data[i].num_outbound_cmds << endl;
        cout << data[i].is_host_login << " " << data[i].is_guest_login << " " << data[i].count << " " << data[i].srv_count << " " << data[i].serror_rate << endl;
        cout << data[i].srv_serror_rate  << " " << data[i].rerror_rate << " " << data[i].srv_rerror_rate << " " << data[i].same_srv_rate << " " << data[i].diff_srv_rate << endl;
        cout << data[i].srv_diff_host_rate << " " << data[i].dst_host_count  << " " <<  data[i].dst_host_srv_count << " " << data[i].dst_host_same_srv_rate << " " << data[i].dst_host_diff_srv_rate << endl;
        cout << data[i].dst_host_same_src_port_rate << " "  << data[i].dst_host_srv_diff_host_rate << " " << data[i].dst_host_serror_rate << " " << data[i].dst_host_srv_serror_rate << " " << data[i].dst_host_rerror_rate << endl;
        cout << data[i].dst_host_srv_rerror_rate << " " << data[i].label << endl << endl;
    }
}

double dist(features a, features b) {
	double res;
    if (FEATURE_DECREASED) {
        res = pow((a.protocol_type - b.protocol_type), 2) +
          pow((a.service - b.service), 2) +
          pow((a.flag - b.flag), 2) +
          pow((a.src_bytes - b.src_bytes), 2) + // 5
          pow((a.dst_bytes - b.dst_bytes), 2) +
          pow((a.num_failed_logins - b.num_failed_logins), 2) +
          pow((a.root_shell - b.root_shell), 2) +
          pow((a.num_root - b.num_root), 2) +
          pow((a.is_guest_login - b.is_guest_login), 2) +
          pow((a.count - b.count), 2) +
          pow((a.srv_count - b.srv_count), 2) +
          pow((a.rerror_rate - b.rerror_rate), 2) +
          pow((a.same_srv_rate - b.same_srv_rate), 2) +
          pow((a.diff_srv_rate - b.diff_srv_rate), 2) + // 30
          pow((a.dst_host_srv_count - b.dst_host_srv_count), 2) +
          pow((a.dst_host_same_srv_rate - b.dst_host_same_srv_rate), 2) +
          pow((a.dst_host_diff_srv_rate - b.dst_host_diff_srv_rate), 2) + // 35
          pow((a.dst_host_same_src_port_rate - b.dst_host_same_src_port_rate), 2) +
          pow((a.dst_host_srv_diff_host_rate - b.dst_host_srv_diff_host_rate), 2) +
          pow((a.dst_host_srv_serror_rate - b.dst_host_srv_serror_rate), 2);
    }
    else {
	   res = pow((a.duration - b.duration), 2) +
          pow((a.protocol_type - b.protocol_type), 2) +
          pow((a.service - b.service), 2) +
          pow((a.flag - b.flag), 2) +
          pow((a.src_bytes - b.src_bytes), 2) + // 5
          pow((a.dst_bytes - b.dst_bytes), 2) +
          pow((a.land - b.land), 2) +
          pow((a.wrong_fragment - b.wrong_fragment), 2) +
          pow((a.urgent - b.urgent), 2) +
          pow((a.hot - b.hot), 2) +    // 10
          pow((a.num_failed_logins - b.num_failed_logins), 2) +
          pow((a.logged_in - b.logged_in), 2) +
          pow((a.num_compromised - b.num_compromised), 2) +
          pow((a.root_shell - b.root_shell), 2) +
          pow((a.su_attempted - b.su_attempted), 2) + // 15
		  pow((a.num_root - b.num_root), 2) +
          pow((a.num_file_creations - b.num_file_creations), 2) +
          pow((a.num_shells - b.num_shells), 2) +
          pow((a.num_access_files - b.num_access_files), 2) +
          pow((a.num_outbound_cmds - b.num_outbound_cmds), 2) + // 20
          pow((a.is_host_login - b.is_host_login), 2) +
          pow((a.is_guest_login - b.is_guest_login), 2) +
		  pow((a.count - b.count), 2) +
          pow((a.srv_count - b.srv_count), 2) +
          pow((a.serror_rate - b.serror_rate), 2) + // 25
          pow((a.srv_serror_rate - b.srv_serror_rate), 2) +
          pow((a.rerror_rate - b.rerror_rate), 2) +
          pow((a.srv_rerror_rate - b.srv_rerror_rate), 2) +
          pow((a.same_srv_rate - b.same_srv_rate), 2) +
          pow((a.diff_srv_rate - b.diff_srv_rate), 2) + // 30
          pow((a.srv_diff_host_rate - b.srv_diff_host_rate), 2) +
          pow((a.dst_host_count - b.dst_host_count), 2) +
          pow((a.dst_host_srv_count - b.dst_host_srv_count), 2) +
          pow((a.dst_host_same_srv_rate - b.dst_host_same_srv_rate), 2) +
          pow((a.dst_host_diff_srv_rate - b.dst_host_diff_srv_rate), 2) + // 35
          pow((a.dst_host_same_src_port_rate - b.dst_host_same_src_port_rate), 2) +
          pow((a.dst_host_srv_diff_host_rate - b.dst_host_srv_diff_host_rate), 2) +
          pow((a.dst_host_serror_rate - b.dst_host_serror_rate), 2) +
          pow((a.dst_host_srv_serror_rate - b.dst_host_srv_serror_rate), 2) +
          pow((a.dst_host_rerror_rate - b.dst_host_rerror_rate), 2) +// 40
          pow((a.dst_host_srv_rerror_rate - b.dst_host_srv_rerror_rate), 2);
      }
	return res;
}