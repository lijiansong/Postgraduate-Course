#Note
This archive is the implementation of KNN. 
Firstly, we evaluated the performance of KNN in the train data set by cross validation. Before reduction, The confusion matrix of training data is 
25963  28     38      3  20
170    618    0       0  0
6  	   20456  146693  0  1
5  	   2  	  0       16 0
0  	   0  	  0       0  1
After reduction, the confusion matrix is
25968  25  	  37      5  17
93     695    0       0  0
278    20474  146404  0  0
4      2  	  1       16 0
0      0  	  0       0  1

Then we calculated the distance between each test sample and the training samples, and choose the k shortest samples from the training set. And then get the predicted label by voting.
By all features or reducted features, the predicted label is shown in result/Guessed_label.feature_undescreased and result/Guessed_label.feature_descreased.


You can redo the experiment as follows:

You must ensure that the file testdata_unlabeled_50000.txt and kddcup.data_10_percent.txt are in the foler knn.

1. Cross Validation: use validation.cpp and control whether reduct features by change the value FEATURE_DECREASED.

2. Predict labels: use knn.cpp and control whether reduct features by change the value FEATURE_DECREASED.